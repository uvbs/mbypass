#pragma once

extern unsigned char aes_table1009e740[];
extern unsigned char aes_table1009df40[];
extern unsigned char aes_table1009db40[];
extern unsigned char aes_table1009e340[];
extern unsigned char aes_table100a0b40[];
extern unsigned char aes_table100a0f40[];
extern unsigned char aes_table100a1340[];
extern unsigned char aes_table100a1740[];
extern unsigned char aes_table1009f340[];
extern unsigned char aes_table1009eb40[];
extern unsigned char aes_table1009ef40[];
extern unsigned char aes_table1009f740[];
extern unsigned char aes_table1009ff40[];
extern unsigned char aes_table100a0340[];
extern unsigned char aes_table1009fb40[];
extern unsigned char aes_table100a0740[];
extern unsigned char aes_table1009cf40[];
extern unsigned char aes_table1009cb40[];
extern unsigned char aes_table1009d340[];
extern unsigned char aes_table1009d740[];